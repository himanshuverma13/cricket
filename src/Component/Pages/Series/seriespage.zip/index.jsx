import React, { useEffect, useState } from "react";
import { GetSeriesDataAPI } from "../../APIs/api";
import moment from "moment";

const Series = () => {
  const [Series, setSeries] = useState();
  const [activeTab, setActiveTab] = useState("international");

  const GetSeriesData = async (payload) => {
    try {
      const response = await GetSeriesDataAPI(payload);
      setSeries(response?.seriesMapProto);
    } catch (error) {
      console.log("error: ", error);
    }
  };

  useEffect(() => {
    GetSeriesData("international");
  }, []);

  const handleTab = (tab) => {
    setActiveTab(tab);
    GetSeriesData(tab);
  };

  let Tabs = ["international", "league", "domestic", "women"];

  return (
    <div className="container mt-5">
      <div className="text-center mb-4">
        <h1 className="display-4">Upcoming Series</h1>
      </div>
      <ul className="nav nav-tabs mb-4">
        {Tabs?.map((tab) => (
          <li className="nav-item" key={tab}>
            <button
              className={`nav-link ${activeTab === tab ? "active" : ""}`}
              onClick={() => handleTab(tab)}
            >
              {tab?.toUpperCase()}
            </button>
          </li>
        ))}
      </ul>

      <div>
        {Series?.length > 0 ? (
          Series?.map((item, index) => (
            <div key={index} className="mb-4">
              <h3 className="font-weight-bold">{item?.date}</h3>
              <ul className="list-group">
                {item.series.map((series, idx) => (
                  <li key={idx} className="list-group-item">
                    <div className="font-weight-semibold">{series?.name}</div>
                    <div className="text-muted">
                      {moment(JSON?.parse(series?.startDt)).format("DD/MM/YY")}{" "}
                      {moment(JSON?.parse(series?.endDt)).format("DD/MM/YY")}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          ))
        ) : (
          <p className="text-muted">No data available for this category.</p>
        )}
      </div>
    </div>
  );
};

export default Series;
